<?php
	include "db.php";
	
	$matricula=$_POST['matricula']; 	
	$aluno_nome=$_POST['aluno_nome'];
	$senha=$_POST['senha'];
	$turma=$_POST['turma'];
         
    $nome_turma = "Turma_$turma";



	$sql = "INSERT INTO alunos_cadastrados (matricula, aluno_nome, senha, turma)
	VALUES ('$matricula', '$aluno_nome', '$senha', '$turma')";

	if ($con->query($sql) === TRUE) {
	   
		$sql_turma = "INSERT INTO $nome_turma (matricula, aluno_nome, turma) 
		VALUES ('$matricula', '$aluno_nome', '$turma')";

		if($con->query($sql_turma) === TRUE){
			echo 1;
		} else {
			echo "Error turma: " . $sql_turma . "<br>" . $con->error;
		}
   
	} else {
	    echo "Error: " . $sql . "<br>" . $con->error;
	}

	$con->close();


 ?>