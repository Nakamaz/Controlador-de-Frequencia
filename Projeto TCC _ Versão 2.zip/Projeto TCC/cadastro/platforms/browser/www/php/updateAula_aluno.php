<?php
	include "db.php";

	$presenca =$_POST['presenca'];
	$nome_aula =$_POST['nome_aula'];
	$matricula =$_POST['matricula'];

	$sql = "UPDATE `".$nome_aula."` SET presenca='$presenca' WHERE matricula_aluno='$matricula'";

	if ($con->query($sql) === TRUE) {

              echo 1;

	} else {
	    echo "Error sql: " . $con->error;	    
	}

 	$con->close();

	
?>		