<?php
 header("Access-Control-Allow-Origin: *");
 $con = new mysqli("mysql.hostinger.com.br","u244029954_user","phlorencio12345","u244029954_banco");

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);

}


?>