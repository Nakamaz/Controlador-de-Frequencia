
<?php
	include "db.php";

	$turma=$_POST['turma'];

	$sql = "SELECT * FROM aulas_ativas WHERE turma='$turma' ";

	$result = $con->query($sql);

	if ($result->num_rows > 0) {
	  	while ($row = $result->fetch_assoc()){
			
	  		$vetor[] = array_map('utf8_encode', $row);

	
		}  

		echo json_encode($vetor);            
	} else {
	    echo "Error: " . $sql . "<br>" . $con->error;	    
	}





 	$con->close();	
?>	


