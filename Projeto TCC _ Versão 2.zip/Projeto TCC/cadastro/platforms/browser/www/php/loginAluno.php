<?php
	include "db.php";
      
    $matricula=$_POST['matricula'];
	$senha=$_POST['senha'];

	$sql = "SELECT * FROM alunos_cadastrados WHERE matricula = '".$matricula."' AND senha = '".$senha."'";
    $result = $con->query($sql);

	if ($result->num_rows > 0) {

           while($row = $result->fetch_assoc()) {
             echo 1;

           }

	} else {
	    echo "Error: " . $sql . "<br>" . $con->error;;
	}

 	$con->close();

	
?>	