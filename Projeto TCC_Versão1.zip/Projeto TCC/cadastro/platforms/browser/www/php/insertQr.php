<?php
	include "db.php";

	$senha=$_POST['senha'];
        $value=$_POST['value'];
	

	$sql = "UPDATE aluno SET value='$value' WHERE senha='$senha'";

	if ($con->query($sql) === TRUE) {
	    echo "success";
	    
	} else {
	    echo "Error: " . $sql . "<br>" . $con->error;
	}

	$con->close();

 ?>		