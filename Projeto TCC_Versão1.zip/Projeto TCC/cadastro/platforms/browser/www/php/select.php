<?php
	include "db.php";
      
        $usuario=$_POST['usuario'];
	$senha=$_POST['senha'];

	$sql = "SELECT * FROM aluno WHERE usuario = '".$usuario."' AND senha = '".$senha."'";
        $result = $con->query($sql);

	if ($result->num_rows > 0) {

           while($row = $result->fetch_assoc()) {
             echo 1;

           }

	} else {
	    echo 0;
	}

 	$con->close();

	
?>								