<?php
	 include "db.php";
	
	 	
	$usuario=$_POST['usuario'];
	$senha=$_POST['senha'];

	$sql = "INSERT INTO aluno (usuario, senha)
	VALUES ('$usuario', '$senha')";

	if ($con->query($sql) === TRUE) {
	    echo "success";
	} else {
	    echo "Error: " . $sql . "<br>" . $con->error;
	}

	$con->close();


 ?>